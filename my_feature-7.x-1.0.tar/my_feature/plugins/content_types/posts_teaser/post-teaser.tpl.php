<div >
  <div>
    <div>
      <div><?php print $image; ?></div>
      <?php print $title; ?>    </div>
    <p><?php print $body; ?>
    </p>
  </div>
</div>
